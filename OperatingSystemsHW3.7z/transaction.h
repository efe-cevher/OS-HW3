struct transaction{
    int day;
    int customerId;
    char** items;
};

typedef struct transaction Transaction;